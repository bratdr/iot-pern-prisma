-- DropIndex
DROP INDEX "Token_token_key";
