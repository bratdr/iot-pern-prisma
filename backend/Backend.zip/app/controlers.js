// Put your controller code here
exports.tes = (req, res) => {
    res.send("work mvc");
};
